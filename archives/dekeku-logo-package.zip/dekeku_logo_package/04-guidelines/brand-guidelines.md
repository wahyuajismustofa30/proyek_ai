# Panduan singkat identitas DEKEKU

**Karakter:** profesional, bersahabat, minimalis.
**Tagline:** YOUR DIGITAL SPACE.

Gunakan logo hitam pada latar terang dan logo putih pada latar gelap. Sisakan ruang kosong minimal setinggi mata maskot di sekeliling logo. Jangan meregangkan, memiringkan, memberi efek bevel, atau mengubah proporsi maskot. Untuk favicon kecil, gunakan ikon maskot saja tanpa wordmark atau tagline.

Warna utama:
- Black `#000000`
- White `#FFFFFF`
- Gray `#777777`

Gambar OG disiapkan pada rasio 1200×630 (1.91:1), sesuai praktik umum preview tautan sosial.
