# DEKEKU — Logo Package

Tagline: **YOUR DIGITAL SPACE**

## Isi paket
- `01-logos/` — logo horizontal transparan, versi terang/gelap, maskot PNG dan SVG.
- `02-icons-favicon/` — ikon terang/gelap, ikon transparan, favicon PNG 16–256 px, dan favicon ICO.
- `03-social/` — gambar Open Graph 1200×630 dalam JPG dan PNG.
- `04-guidelines/` — panduan singkat penggunaan.

## Warna
- Hitam utama: `#000000`
- Putih: `#FFFFFF`
- Abu-abu pendukung: `#777777`

## Rekomendasi penggunaan
- Header website: `dekeku-logo-horizontal-transparent.png`
- Background terang: `dekeku-logo-horizontal-light.png`
- Background gelap: `dekeku-logo-horizontal-dark.png`
- Favicon: `favicon.ico` atau PNG sesuai ukuran.
- Avatar GitHub: `dekeku-icon-light-512.png` atau `dekeku-icon-dark-512.png`
- Open Graph: `og-image-1200x630.jpg`

## Meta tag OG
```html
<meta property="og:type" content="website">
<meta property="og:title" content="DEKEKU — YOUR DIGITAL SPACE">
<meta property="og:description" content="Web development and digital solutions.">
<meta property="og:image" content="https://YOUR-DOMAIN/og-image-1200x630.jpg">
<meta property="og:image:width" content="1200">
<meta property="og:image:height" content="630">
<meta name="twitter:card" content="summary_large_image">
```

Catatan: file SVG dalam paket ini adalah pembungkus SVG dengan PNG tertanam (raster), bukan artwork path vektor. Untuk hasil cetak besar atau pengubahan bentuk, sebaiknya dibuat ulang sebagai SVG vektor final.
